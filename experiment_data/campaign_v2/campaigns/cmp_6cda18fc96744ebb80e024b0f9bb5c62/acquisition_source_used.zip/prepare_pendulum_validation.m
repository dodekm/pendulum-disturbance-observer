function out=prepare_pendulum_validation(options)
%PREPARE_PENDULUM_VALIDATION Preview/freeze three fresh physical holdouts.
% Never opens UART. A separate fresh runtime arm is required for acquisition.
arguments
    options.Mode (1,1) string = "preview"
    options.CandidateId (1,1) string = "candidate_20261106_164923_b986ef83-b409-4175-b1a2-bbac9c0cd4f7"
end
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'experiment_framework'),fullfile(root,'experiment_framework','analyses'));
assert(any(options.Mode==["preview","freeze"]),'Use preview or freeze.');
id=char(options.CandidateId);
candidate=pendulumlab.load_model(string(id),string(fullfile(root,'experiment_framework','model_registry')));
assert(strcmp(candidate.status,'candidate')&&candidate.fit.converged);
diagnosticSource=fullfile(root,'experiment_data','campaign_v2','identification_results','identification_20261106_163437','identification.mat');
z=load(diagnosticSource,'report');diagnostic=z.report.models{3}.parameters_full;
cfg=pendulumlab.default_config('validation');cfg.theta=double(candidate.theta(:).');
cfg.model_id=id;cfg.model_status='candidate';cfg.model_hardware_id=candidate.hardware_id;
calibrated=isfield(candidate,'actuator_calibration');
if calibrated
    cfg.actuator_calibration=candidate.actuator_calibration;cfg.u_limits=[0 62];
    cfg.mock.theta=cfg.theta;cfg.mock.actuator_lag_s=candidate.plant_characterization.lag_s;
end
cfg.validation_candidate_sha256=candidate.registry_file_hash;
cfg.validation_diagnostic_source_sha256=pendulumlab.file_hash(diagnosticSource);
cfg.experiment_launcher_source_sha256=pendulumlab.file_hash([mfilename('fullpath') '.m']);
cfg.hardware.COM_port=4;cfg.safety.max_slew_units_s=40;
cfg.campaign.intertrial_recovery_s=20;cfg.session_id='revision_validation_session_20261106';
cfg.campaign.plan='validation';cfg.async_checkpoint=true;
cfg.session_deadline_utc='2026-11-06T19:45:00Z';cfg.latest_start_utc='2026-11-06T19:40:00Z';
criteria=struct('id','nominal_accuracy_20261106_v1','max_candidate_rmse_rad',deg2rad(5), ...
    'max_abs_bias_rad',deg2rad(3),'max_peak_abs_error_rad',deg2rad(15), ...
    'max_powered_rmse_rad',deg2rad(5),'max_abs_powered_bias_rad',deg2rad(3), ...
    'min_powered_duration_s',40,'max_substep_doubling_rad',1e-4, ...
    'require_acquisition_binding',true, ...
    'rationale',['Prospective engineering accuracy targets: 5-deg RMS is one third of the planned 15-deg reference increment; ', ...
    '3-deg bias is one fifth; 15-deg peak permits one increment of transient prediction error. ', ...
    'These are declared accuracy targets, not universal stability/safety margins. Failure remains a finding; no post-data relaxation. ', ...
    'Positive-command scoring prevents long quiet returns from concealing error. No automatic human control approval.']);
if options.Mode=="freeze"
    if calibrated
        criteria.id='calibrated_rig_accuracy_20261106_v1';
        criteria.validation_scope=['Accuracy applies to the full identified rig predictor (static map plus actuator lag), ', ...
            'not to the nominal second-order DOB inverse or a robust-stability guarantee.'];
    end
    criteria=pendulumlab.freeze_model_criteria(criteria,"Revision protocol prepared under Martin Dodek's experimental authorization");
    cfg.validation_criteria_sha256=criteria.criteria_sha256;
end
profiles=repmat(struct('experiment_id','validation_angle_coverage','protocol',cfg.protocol),1,3);
w={[0 0;5 0;27 44;39 44;43 52;55 52;58 58;70 58;73 52;85 52;89 44;101 44;123 0;150 0]};
if calibrated
    w{1}=[0 0;5 0;27 44;37 44;41 52;51 52;54 58;64 58;68 62;74 62;78 58;88 58;91 52;101 52;105 44;115 44;137 0;160 0];
end
designs=cell(1,3);designs{1}=struct('kind','ascending_descending_plateaus','tail_window_s',6);
for j=2:3
    bias=52;amp=2;if j==3,bias=58;amp=1.5;end
    seed=6400+j-1;
    if calibrated,amp=1.5;if j==3,amp=1;end;seed=9400+j-1;end
    [w{j},designs{j}]=waveform(bias,amp,seed);
end
previews=cell(1,3);
for j=1:3
    p=cfg.protocol;p.static_waypoints=w{j};p.duration_s=w{j}(end,1);p.baseline_s=5;
    p.bias_command=max(w{j}(:,2));p.amplitude_command=0;p.ramp_s=w{j}(3,1)-5;p.dwell_s=12;
    p.command_slew_units_s=30;p.validation_design=designs{j};
    deadline=w{j}(end-1,1);if j>1,deadline=104;p.multisine_design=designs{j};end
    p.return_policy=struct('version','angle_zero_return_v1','target_abs_angle_rad',deg2rad(85), ...
        'active_deadline_s',deadline,'required_zero_tail_s',20,'direct_zero_approved',true);
    profiles(j).protocol=p;c=cfg;c.experiment_id='validation_angle_coverage';c.protocol=p;
    schedule=pendulumlab.make_schedule(c);u=double(single(schedule.command));
    if calibrated
        [nominal,nominalU]=screen(diagnostic,schedule.t,u,p.return_policy);
    else
        [nominal,nominalU]=screen([cfg.theta 0 0 0],schedule.t,u,p.return_policy);
    end
    comparisonParameters=diagnostic;if calibrated,comparisonParameters(5)=0;end
    [rich,richU]=screen(comparisonParameters,schedule.t,u,p.return_policy);
    assert(max(abs(rad2deg([nominal;rich])))<120,'A planning case exceeds the existing preview screening limit.');
    assert(max(abs(diff(u)))/cfg.Ts<30,'Planned wire slew lacks the declared runtime headroom.');
    previews{j}=struct('t',schedule.t,'requested_u',u,'nominal_y',nominal,'diagnostic_y',rich, ...
        'nominal_u',nominalU,'diagnostic_u',richU,'design',designs{j});
end
cfg.campaign.validation_profiles=profiles;
out=struct('state','preview','config',cfg,'candidate',candidate,'criteria',criteria,'previews',{previews},'manifest_path','');
f=figure('Visible','off','Color','w','Position',[30 30 1100 900]);tiledlayout(f,3,2,'TileSpacing','compact');
for j=1:3
    p=previews{j};nexttile;plot(p.t,rad2deg([p.nominal_y p.diagnostic_y]),'LineWidth',1);grid on;
    xlabel('t [s]');ylabel('Simulated y [deg]');
    if calibrated,legend('Identified rig (map + lag)','Second-order nominal approximation','Location','best');
    else,legend('Nominal candidate','Map + lag diagnostic','Location','best');end
    nexttile;plot(p.t,[p.requested_u p.nominal_u p.diagnostic_u]);grid on;xlabel('t [s]');ylabel('Command units');
end
exportgraphics(f,fullfile(tempdir,'pendulum_validation_preview.png'),'Resolution',130);close(f);
if options.Mode=="preview",return,end
cfg.mode='hardware';cfg.output_dir=fullfile(root,'experiment_data','campaign_v2');
cfg.hardware.enabled=true;cfg.hardware.operator_armed=true;
cfg.hardware.mechanical_ready=true;cfg.hardware.angle_zero_confirmed=true;
for j=1:3
    cfg.campaign.validation_profiles(j).protocol.operating_envelope_approved=true;
    cfg.campaign.validation_profiles(j).protocol.operator_excitation_approved=true;
end
cfg.protocol=cfg.campaign.validation_profiles(1).protocol;cfg.experiment_id='validation_angle_coverage';
ready=pendulumlab.validate_config(cfg);assert(ready.hardware_allowed,'%s',strjoin(ready.issues,'; '));
manifest=pendulumlab.prepare_campaign(cfg,'validation');out.config=cfg;out.manifest_path=manifest.manifest_path;
out.state='frozen_not_armed';derived=fullfile(manifest.campaign_folder,'derived');mkdir(derived);
plan=struct('candidate',candidate,'criteria',criteria,'diagnostic_parameters',diagnostic, ...
    'diagnostic_source',diagnosticSource,'diagnostic_source_sha256',cfg.validation_diagnostic_source_sha256, ...
    'state_prefix_s',5,'substeps',8,'signal_convention','Raw encoder angle, held actual transmitted command, no angle offset; prefix-only nuisance velocity.', ...
    'manifest_path',manifest.manifest_path,'manifest_sha256',manifest.manifest_sha256, ...
    'scope','All three prospective outcomes are reported. Interlocks/early return may limit coverage; these are not Off/On repetitions.');
if calibrated
    plan.scope=[plan.scope ' Candidate prediction includes identified static map and actuator lag; the controller/DOB still use the second-order nominal model in calibrated coordinates.'];
end
save(fullfile(derived,'validation_plan.mat'),'plan','previews','-v7');
fid=fopen(fullfile(derived,'validation_plan.json'),'wt');assert(fid>=0);h=onCleanup(@()fclose(fid));fprintf(fid,'%s',jsonencode(plan,PrettyPrint=true));clear h
zip(fullfile(manifest.campaign_folder,'acquisition_source_used.zip'), ...
    {'prepare_pendulum_validation.m','prepare_pendulum_campaign.m','verify_pendulum_framework.m','experiment_framework/+pendulumlab'},root);
fprintf('FROZEN VALIDATION %s\n',manifest.manifest_path);
end
function [w,d]=waveform(bias,amplitude,seed)
freq=[.25 .5 .75 1 1.25 1.5 2];stream=RandStream('mt19937ar','Seed',seed);
tt=(0:.05:8-.05)';ta=(.05:.05:64)';env=ones(size(ta));
a=ta<8;env(a)=.5-.5*cos(pi*ta(a)/8);a=ta>56;env(a)=.5-.5*cos(pi*(64-ta(a))/8);
best=Inf;
for k=1:512
    ph=2*pi*rand(stream,1,numel(freq));pk=max(abs(sum(sin(2*pi*tt*freq+ph),2)));
    c=bias+amplitude*env.*sum(sin(2*pi*ta*freq+ph),2)/pk;
    if max(abs(diff([bias;c])))/.05<=28&&pk<best,best=pk;phases=ph;end
end
assert(isfinite(best));cmd=bias+amplitude*env.*sum(sin(2*pi*ta*freq+phases),2)/best;
w=[0 0;5 0;30 bias;40 bias;40+ta cmd;124 0;150 0];
d=struct('kind','fresh_multisine','bias_command',bias,'amplitude_command',amplitude, ...
    'seed',seed,'phases_rad',phases,'frequencies_hz',freq,'active_interval_s',[40 104], ...
    'full_amplitude_interval_s',[48 96],'ramp_envelope_s',8,'phase_draws',512);
end
function [y,actual]=screen(p,t,u,policy)
actual=u;actual(t>=policy.active_deadline_s)=0;
y=simulate_identification_model(p,t,actual,[0;0],8,.03);
hit=find(abs(y)>=policy.target_abs_angle_rad&t<policy.active_deadline_s,1);
if ~isempty(hit),actual(hit:end)=0;y=simulate_identification_model(p,t,actual,[0;0],8,.03);end
end
