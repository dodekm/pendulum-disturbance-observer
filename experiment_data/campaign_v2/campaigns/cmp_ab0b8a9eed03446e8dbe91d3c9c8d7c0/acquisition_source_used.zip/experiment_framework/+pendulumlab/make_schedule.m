function schedule = make_schedule(cfg)
%MAKE_SCHEDULE Deterministic plans only; synthetic defaults are not hardware limits.
name=string(cfg.experiment_id);Ts=cfg.Ts;p=cfg.protocol;
plannedSlew=NaN;
switch name
    case "reference_tracking"
        levels=p.reference_levels_rad(:); dwell=p.plateau_s;
        n=max(1,round(dwell/Ts)); reference=repelem(levels,n);
        t=(0:numel(reference)-1)'*Ts;injection=zeros(size(t));command=nan(size(t));
    case "injected_disturbance"
        t=(0:round(70/Ts)-1)'*Ts;reference=repmat(pi/4,size(t));
        injection=zeros(size(t));amp=p.injection_amplitude;
        injection(t>=10&t<20)=amp;injection(t>=30&t<40)=-amp;
        state=rng;guard=onCleanup(@()rng(state));rng(cfg.rng_seed,'twister');
        mask=t>=50;n=sum(mask);holdN=max(1,round(5/Ts));
        values=amp*(2*rand(ceil(n/holdN),1)-1);
        extended=repelem(values,holdN);injection(mask)=extended(1:n);
        clear guard
        command=nan(size(t));
    case {"identification_multilevel","identification_prbs","identification_multisine","validation_multilevel","validation_multisine"}
        n=max(2,round(p.duration_s/Ts));t=(0:n-1)'*Ts;
        assert(p.baseline_s>=0&&p.ramp_s>0&&p.baseline_s+p.ramp_s<p.duration_s, ...
            'pendulumlab:Schedule','Baseline/ramp must leave an excitation interval.');
        assert(p.bias_command-p.amplitude_command>=cfg.u_limits(1)&& ...
            p.bias_command+p.amplitude_command<=cfg.u_limits(2), ...
            'pendulumlab:ExcitationRange','Requested excitation exceeds command limits.');
        command=zeros(size(t));ramp=t>=p.baseline_s&t<p.baseline_s+p.ramp_s;
        command(ramp)=p.bias_command*(t(ramp)-p.baseline_s)/p.ramp_s;
        active=t>=p.baseline_s+p.ramp_s;ta=t(active)-p.baseline_s-p.ramp_s;
        stream=RandStream('mt19937ar','Seed',p.seed);
        if contains(name,'multisine')
            freq=p.multisine_hz(:);
            assert(all(isfinite(freq)&freq>0&freq<1/(2*Ts)),'pendulumlab:Frequency','Excitation frequencies must be positive and below Nyquist.');
            wave=zeros(size(ta));
            for k=1:numel(freq)
                % Seeded phases make independently scheduled validation
                % realizations distinct without changing the frequency set.
                phase=-pi*k*(k-1)/numel(freq)+2*pi*rand(stream);
                wave=wave+sin(2*pi*freq(k)*ta+phase);
            end
            wave=wave/max(max(abs(wave)),eps);
        else
            holdN=max(1,round(p.dwell_s/Ts));count=ceil(numel(ta)/holdN);
            if contains(name,'prbs')
                values=2*randi(stream,2,count,1)-3;
            else
                levels=[-1;-.5;0;.5;1];values=zeros(count,1);
                for k=1:5:count
                    perm=randperm(stream,5);nHere=min(5,count-k+1);
                    values(k:k+nHere-1)=levels(perm(1:nHere));
                end
            end
            wave=repelem(values,holdN);wave=wave(1:numel(ta));
        end
        command(active)=p.bias_command+p.amplitude_command*wave;
        % If configured, shape the planned excitation offline; never alter
        % feedback control to hide a runtime slew interlock.
        plannedSlew=cfg.safety.max_slew_units_s;
        if isfield(p,'command_slew_units_s')
            plannedSlew=p.command_slew_units_s;
            assert(isnumeric(plannedSlew)&&isreal(plannedSlew)&&isscalar(plannedSlew)&& ...
                isfinite(plannedSlew)&&plannedSlew>0,'pendulumlab:PlannedSlew','Planned excitation slew must be positive and finite.');
            if isfinite(cfg.safety.max_slew_units_s)
                assert(plannedSlew<cfg.safety.max_slew_units_s,'pendulumlab:PlannedSlew', ...
                    'Planned excitation slew must be below the approved runtime slew limit, with timing/quantization headroom.');
            end
        end
        if isfinite(plannedSlew)&&plannedSlew>0
            delta=plannedSlew*Ts;
            for k=2:n
                command(k)=command(k-1)+max(-delta,min(delta,command(k)-command(k-1)));
            end
        end
        reference=zeros(size(t));injection=zeros(size(t));
    otherwise
        error('pendulumlab:Protocol','Unsupported protocol %s',name);
end
schedule=struct('name',char(name),'role',cfg.phase,'seed',p.seed, ...
    'injection_seed',cfg.rng_seed,'duration_s',numel(t)*Ts, ...
    't',t,'reference',reference,'injection',injection,'command',command, ...
    'approved_physical_envelope',logical(p.operating_envelope_approved));
if startsWith(name,'identification_')||startsWith(name,'validation_')
    schedule.excitation=struct('bias_command',p.bias_command,'amplitude_command',p.amplitude_command, ...
        'baseline_s',p.baseline_s,'ramp_s',p.ramp_s,'dwell_s',p.dwell_s, ...
        'planned_slew_units_s',plannedSlew,'multisine_hz',p.multisine_hz);
end
assert(all(isfinite(t))&&all(diff(t)>0),'pendulumlab:Time','Invalid schedule time.');
end
