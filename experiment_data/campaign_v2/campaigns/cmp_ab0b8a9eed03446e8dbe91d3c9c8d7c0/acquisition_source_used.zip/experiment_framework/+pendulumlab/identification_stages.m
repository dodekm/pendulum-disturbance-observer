function stages=identification_stages(cfg)
%IDENTIFICATION_STAGES Shared five-run specifications for preview and freezing.
names={'identification_multilevel','identification_multilevel', ...
    'identification_multilevel','identification_prbs','identification_multisine'};
profiles=[];
if isfield(cfg.campaign,'identification_profiles'),profiles=cfg.campaign.identification_profiles;end
if ~isempty(profiles)
    fields={'experiment_id','bias_command','amplitude_command','ramp_s','dwell_s','command_slew_units_s'};
    assert(isstruct(profiles)&&numel(profiles)==5&&all(isfield(profiles,fields)), ...
        'pendulumlab:StageProfile','Provide five complete identification profiles.');
end
stages=repmat(struct('experiment_id','','protocol',struct()),5,1);
for k=1:5
    p=cfg.protocol;name=names{k};
    if ~isempty(profiles)
        name=char(profiles(k).experiment_id);
        assert(any(strcmp(name,names)),'pendulumlab:StageProfile','Invalid identification protocol.');
        for key={'bias_command','amplitude_command','ramp_s','dwell_s','command_slew_units_s'}
            value=profiles(k).(key{1});
            assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value)&&value>=0, ...
                'pendulumlab:StageProfile','Stage %d has an invalid %s.',k,key{1});
            p.(key{1})=value;
        end
        assert(p.ramp_s>0&&p.dwell_s>0&&p.command_slew_units_s>0, ...
            'pendulumlab:StageProfile','Stage timing and planned slew must be positive.');
    elseif isfield(cfg.campaign,'identification_bias_commands')&&~isempty(cfg.campaign.identification_bias_commands)
        values=cfg.campaign.identification_bias_commands;
        assert(isnumeric(values)&&numel(values)==5&&all(isfinite(values(:))), ...
            'pendulumlab:StageBias','identification_bias_commands requires five finite values.');
        p.bias_command=values(k);
    end
    p.seed=cfg.protocol.seed+100*k;
    stages(k)=struct('experiment_id',name,'protocol',p);
end
end
