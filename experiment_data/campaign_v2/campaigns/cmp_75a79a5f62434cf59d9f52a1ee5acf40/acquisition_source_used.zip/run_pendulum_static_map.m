function out=run_pendulum_static_map(options)
%RUN_PENDULUM_STATIC_MAP One static, angle-coverage, or dynamic commissioning record.
% Default preview opens no UART. Settings are at the beginning of this file.
arguments
    options.Mode (1,1) string = "preview"
    options.Profile (1,1) string = "low"
    options.MaximumCommand (1,1) double = 62
    options.Expedited (1,1) logical = false
    options.HoldReviewPath (1,1) string = ""
    options.HardwareArmed (1,1) logical = false
    options.MechanicalReady (1,1) logical = false
    options.AngleZeroConfirmed (1,1) logical = false
    options.ExcitationApproved (1,1) logical = false
    options.OperatingEnvelopeApproved (1,1) logical = false
    options.StopFile (1,1) string = ""
end
settings.campaign_label='revision_static_01';
settings.preceding_campaign_label='revision_ringdown_01';
settings.operator_id='Martin Dodek';settings.session_id='revision_id_session_01';
% [time in seconds, command]. Flat sections are 20-s observation plateaus.
settings.waypoints=[0 0;5 0;15 20;35 20;40 25;60 25;65 30;85 30; ...
    90 25;110 25;115 20;135 20;145 0;165 0];
assert(any(options.Profile==["low","extended","coverage55","coverage90","dynamic45","dynamic60"]),'Unknown commissioning profile.');
if options.Profile=="extended"
    settings.campaign_label='revision_static_02';
    settings.preceding_campaign_label='revision_static_01';
    settings.waypoints=[0 0;5 0;20 30;40 30;43.75 37.5;63.75 37.5; ...
        67.5 45;87.5 45;91.25 37.5;111.25 37.5;115 30;135 30;150 0;170 0];
end
dynamic=any(options.Profile==["dynamic45","dynamic60"]);
coverage=any(options.Profile==["coverage55","coverage90"])||dynamic;
if coverage
    settings.campaign_label='revision_angle_calibration_01';settings.preceding_campaign_label='revision_static_02';
    settings.waypoints=[0 0;5 0;35 45;45 45;50 50;60 50;65 55;100 55;130 0;160 0];
    deadline=100;
    if options.Profile=="coverage90"
        cap=options.MaximumCommand;assert(isfinite(cap)&&cap>55&&cap<=65,'The reviewed target profile requires a cap in (55,65].');
        settings.campaign_label='revision_angle90_01';settings.preceding_campaign_label='revision_angle_calibration_01';
        settings.waypoints=[0 0;5 0;35 45;45 45;50 50;60 50;65 55;75 55; ...
            75+3*(cap-55) cap;110 cap;110+cap/2 0;170 0];deadline=110;
    end
    settings.return_policy=struct('version','angle_zero_return_v1','target_abs_angle_rad',pi/2, ...
        'active_deadline_s',deadline,'required_zero_tail_s',20,'direct_zero_approved',true);
end
if options.Expedited
    assert(options.Profile=="coverage90",'Expedited mode is for the target-coverage retry only.');
    cap=options.MaximumCommand;assert(cap>55&&cap<=65&&isfinite(cap));
    settings.campaign_label='revision_angle90_02';settings.preceding_campaign_label='revision_angle90_01';
    settings.waypoints=[0 0;5 0;25 55;30 55;45 cap;50 cap;50+cap/3 0;100 0];
    deadline=50;settings.return_policy.active_deadline_s=deadline;
end
if dynamic
    bias=52;settings.campaign_label='revision_dynamic45_01';settings.preceding_campaign_label='revision_angle90_02';
    if options.Profile=="dynamic60",bias=58;settings.campaign_label='revision_dynamic60_01';settings.preceding_campaign_label='revision_dynamic45_01';end
    settings.multisine_hz=[.25 .5 .75 1 1.25 1.5 2];settings.phase_seed=3217;
    settings.bias_command=bias;settings.amplitude_command=4;
    [settings.waypoints,settings.multisine_design]=dynamicWaypoints(bias,4,settings.multisine_hz,settings.phase_seed);
    deadline=104;settings.return_policy.active_deadline_s=deadline;
    settings.return_policy.target_abs_angle_rad=deg2rad(85);
end
settings.planned_slew=2;settings.runtime_slew=40;settings.recovery_s=20;
if options.Expedited,settings.planned_slew=3;end
if dynamic,settings.planned_slew=30;end
settings.max_abs_angle_deg=180;settings.COM_port=4;
settings.tail_window_s=10; % frozen descriptive scoring window, not a settling claim
root=fileparts(mfilename('fullpath'));addpath(root);addpath(fullfile(root,'experiment_framework'));
assert(any(options.Mode==["preview","hardware"]),'Use preview or hardware.');
protected=pendulumlab.verify_protected();assert(protected.passed,'Protected project files changed.');
cfg=pendulumlab.default_config('identification');cfg.mode='mock';
cfg.experiment_launcher_source_sha256=pendulumlab.file_hash([mfilename('fullpath') '.m']);
cfg.experiment_id='identification_static_map';cfg.protocol.static_waypoints=settings.waypoints;
if coverage,cfg.experiment_id='identification_angle_coverage';cfg.protocol.return_policy=settings.return_policy;end
if dynamic
    cfg.protocol.multisine_hz=settings.multisine_hz;
    cfg.protocol.multisine_design=settings.multisine_design;
end
cfg.protocol.duration_s=settings.waypoints(end,1);cfg.protocol.baseline_s=settings.waypoints(2,1);
cfg.protocol.bias_command=max(settings.waypoints(:,2));cfg.protocol.amplitude_command=0;
flat=find(diff(settings.waypoints(:,2))==0&settings.waypoints(1:end-1,2)>0);
holds=settings.waypoints(flat+1,1)-settings.waypoints(flat,1);
cfg.protocol.ramp_s=settings.waypoints(3,1)-settings.waypoints(2,1);cfg.protocol.dwell_s=min(holds);cfg.protocol.seed=3117;
cfg.protocol.command_slew_units_s=settings.planned_slew;
cfg.safety.max_abs_angle_rad=deg2rad(settings.max_abs_angle_deg);
cfg.safety.max_slew_units_s=settings.runtime_slew;cfg.safety.max_duration_s=180;
cfg.hardware.COM_port=settings.COM_port;cfg.analysis.static_tail_window_s=settings.tail_window_s;
cfg.campaign.plan='identification';cfg.campaign.intertrial_recovery_s=settings.recovery_s;
cfg.campaign.identification_profiles=struct('experiment_id',cfg.experiment_id, ...
    'bias_command',cfg.protocol.bias_command,'amplitude_command',0,'ramp_s',cfg.protocol.ramp_s, ...
    'dwell_s',cfg.protocol.dwell_s,'command_slew_units_s',settings.planned_slew);
cfg.experiment_notes=['Identification commissioning (' char(options.Profile) '): frozen requested waveform and optional latched zero return; use actual transmitted input. Actual thrust is unmeasured.'];
st=pendulumlab.identification_stages(cfg);previewCfg=cfg;
previewCfg.protocol=st.protocol;previewCfg.rng_seed=cfg.rng_seed+1;
schedule=pendulumlab.make_schedule(previewCfg);u=double(single(schedule.command));
old=fullfile(root,'experiment_data','campaign_v2','campaigns', ...
    'cmp_ab0b8a9eed03446e8dbe91d3c9c8d7c0','derived');
z=load(fullfile(old,'identification_20261106_141039','identification.mat'),'report');
theta=[z.report.settings.historical_theta;z.report.individual{1}.theta;z.report.individual{2}.theta];
pred=zeros(numel(u),4);applied=repmat(u,1,4);policy=[];returnStates=cell(1,4);
caseLabels={'Historical','Run 1 fit','Run 2 fit','Earlier quadratic + lag'};
if coverage,policy=pendulumlab.identification_return(cfg);end
for k=1:3
    if coverage,[pred(:,k),applied(:,k),returnStates{k}]=lagResponse([theta(k,:) 0],schedule.t,u,4,false,policy);
    else,pred(:,k)=pendulumlab.simulate_output(theta(k,:),schedule.t,u,[0;0],4);end
end
diagnostic=fullfile(old,'mismatch_diagnostics_20261106_142624','diagnostics.mat');
z=load(diagnostic,'report');p=z.report.results{5}.pooled.parameters;
% Static nonlinearity and exact held-input first-order forcing are used only
% to screen the proposed input, not to replace the controller's nominal model.
[pred(:,4),applied(:,4),returnStates{4}]=lagResponse(p,schedule.t,u,4,true,policy);
currentSource=fullfile(root,'experiment_data','campaign_v2','identification_results','identification_20261106_155235','identification.mat');
if dynamic
    current=load(currentSource,'report');currentP=current.report.models{3}.parameters_full;
    [pred(:,5),applied(:,5),returnStates{5}]=lagResponse(currentP,schedule.t,u,8,true,policy);
    caseLabels{5}='Current nonlinear map + lag';
end
preview=struct('settings',settings,'theta_cases',theta,'quadratic_lag_parameters',p, ...
    't',schedule.t,'u',u,'predicted_applied_u',applied,'predicted_angle_rad',pred, ...
    'angle_ranges_deg',rad2deg([min(pred,[],1);max(pred,[],1)]), ...
    'max_payload_slew_units_s',max(abs(diff(u)))/cfg.Ts, ...
    'lag_substep_doubling_max_deg',rad2deg(max(abs(pred(:,4)-lagResponse(p,schedule.t,u,8,true,policy)))), ...
    'model_note','Provisional model cases, not a probability envelope or physical safety guarantee.', ...
    'diagnostic_source_sha256',pendulumlab.file_hash(diagnostic), ...
    'launcher_sha256',cfg.experiment_launcher_source_sha256);
preview.case_labels=caseLabels;
preview.return_states=returnStates;
preview.schedule_identity_sha256=pendulumlab.schedule_identity_sha256(schedule);
if dynamic
    preview.current_candidate_source_sha256=pendulumlab.file_hash(currentSource);preview.current_candidate_parameters=currentP;
    preview.current_substep_doubling_max_deg=rad2deg(max(abs(pred(:,5)-lagResponse(currentP,schedule.t,u,16,true,policy))));
end
if coverage
    assert(max(abs(preview.angle_ranges_deg(:)))<120,'A target-return screening case overshoots 120 degrees; revise the waveform.');
else
    assert(max(abs(preview.angle_ranges_deg(:)))<90,'A planning case exceeds the design target.');
end
assert(preview.max_payload_slew_units_s<settings.runtime_slew,'Payload slew exceeds runtime interlock.');
assert(cfg.protocol.duration_s+cfg.safety.rest_samples*cfg.Ts+5<cfg.safety.max_duration_s, ...
    'Leave timing headroom for connection, rest and acquisition.');
out=struct('state','preview','preview',preview,'preview_config',previewCfg, ...
    'campaign_config',cfg,'manifest_path','','report',struct());
fprintf('Commissioning plan: %s; planned holds %s s; %.1f s; scheduled zero from %.1f s.\n', ...
    strjoin(cellstr(compose('%g',schedule.excitation.plateau_commands)),' -> '), ...
    mat2str(holds'),cfg.protocol.duration_s,schedule.excitation.command_zero_start_s);disp(preview.angle_ranges_deg);
if coverage,fprintf('Latched zero return at measured |angle| >= %.1f deg or %.1f s deadline.\n',rad2deg(settings.return_policy.target_abs_angle_rad),deadline);end
if options.Mode=="preview"
    drawPreview(preview);return
end
assert(options.HardwareArmed&&options.MechanicalReady&&options.AngleZeroConfirmed&& ...
    options.ExcitationApproved&&options.OperatingEnvelopeApproved,'pendulumlab:HardwareArm', ...
    'Explicit current-session confirmations are required.');
assert(strlength(options.StopFile)>0&&~isfile(options.StopFile),'Provide a fresh nonexistent stop-flag path.');
% Enforce recovery from the previous physical recording across campaign labels.
last=jsondecode(fileread(fullfile(root,'experiment_data','campaign_v2','identification_campaigns',[settings.preceding_campaign_label '.json'])));
lastStatus=jsondecode(fileread(fullfile(fileparts(last.manifest_path),'campaign_status.json')));
[ok,reason]=pendulumlab.recovery_gate(lastStatus.runs,settings.recovery_s);assert(ok,'%s',reason);
if any(ismember(string({lastStatus.runs.code}),["fault","interlock","aborted","blocked"]))
    assert(strlength(options.HoldReviewPath)>0&&isfile(options.HoldReviewPath),'A bound operator review is required after the previous interlock.');
    review=jsondecode(fileread(options.HoldReviewPath));
    assert(strcmpi(strtrim(fileread([char(options.HoldReviewPath) '.sha256'])),pendulumlab.file_hash(char(options.HoldReviewPath))));
    row=lastStatus.runs(1);
    assert(isequal(review.allow_continue,true)&&strcmp(review.run_id,row.run_id)&& ...
        strcmp(review.original_status,row.code)&&strcmp(review.original_reason,row.reason)&& ...
        strcmpi(review.manifest_sha256,pendulumlab.file_hash(last.manifest_path))&& ...
        strcmpi(review.result_sha256,pendulumlab.file_hash(row.result_file)),'Review does not bind the exact prior result.');
    cfg.prior_hold_review=struct('path',char(options.HoldReviewPath),'sha256',pendulumlab.file_hash(char(options.HoldReviewPath)));
end
% Exercise shared MATLAB code and checkpoint polling before COM is opened.
% This mitigates first-use overhead; hardware timing guards remain unchanged.
warmCfg=pendulumlab.default_config('identification');warmCfg.mode='mock';
warmCfg.output_dir=fullfile(tempdir,['pendulumlab_startup_warm_' char(java.util.UUID.randomUUID)]);
warmCfg.run_id=['warm_' char(java.util.UUID.randomUUID)];warmCfg.async_checkpoint=true;
warmCfg.protocol.duration_s=2;warmCfg.protocol.baseline_s=.25;warmCfg.protocol.ramp_s=.25;
warmCfg.protocol.bias_command=1;warmCfg.protocol.amplitude_command=0;warmCfg.safety.max_slew_units_s=40;
warmClock=tic;warmResult=pendulumlab.run_trial(warmCfg,pendulumlab.make_schedule(warmCfg));
assert(strcmp(warmResult.status.code,'completed')&&strcmp(warmResult.recording_kind,'synthetic'),'Offline acquisition warmup failed.');
warmup=struct('kind','synthetic_only','elapsed_s',toc(warmClock),'samples',numel(warmResult.signals.t), ...
    'UART_opened',false,'source_file',fullfile(warmCfg.output_dir,'runs',[warmCfg.run_id '.mat']));
out.startup_warmup=warmup;
cfg.mode='hardware';cfg.output_dir=fullfile(root,'experiment_data','campaign_v2');cfg.session_id='';
cfg.hardware.enabled=true;cfg.hardware.operator_armed=options.HardwareArmed;
cfg.hardware.mechanical_ready=options.MechanicalReady;cfg.hardware.angle_zero_confirmed=options.AngleZeroConfirmed;
cfg.protocol.operator_excitation_approved=options.ExcitationApproved;
cfg.protocol.operating_envelope_approved=options.OperatingEnvelopeApproved;
ready=pendulumlab.validate_config(cfg);assert(ready.hardware_allowed,'%s',strjoin(ready.issues,'; '));
pointer=fullfile(cfg.output_dir,'identification_campaigns',[settings.campaign_label '.json']);
if isfile(pointer)
    q=jsondecode(fileread(pointer));
    assert(strcmp(q.config_sha256,pendulumlab.json_value_sha256(cfg)),'Settings changed under this label.');
    assert(strcmp(q.manifest_sha256,pendulumlab.file_hash(q.manifest_path)),'Frozen manifest changed.');
    manifestPath=q.manifest_path;
else
    manifest=pendulumlab.prepare_campaign(cfg,'identification');manifestPath=manifest.manifest_path;
    frozen=load(fullfile(manifest.campaign_folder,manifest.runs(1).schedule_file),'schedule');
    assert(strcmp(pendulumlab.schedule_identity_sha256(schedule),pendulumlab.schedule_identity_sha256(frozen.schedule)), ...
        'Frozen waveform differs from the preview.');
    q=struct('schema_version','pendulumlab.static_launcher/1','config_sha256',pendulumlab.json_value_sha256(cfg), ...
        'manifest_path',manifestPath,'manifest_sha256',manifest.manifest_sha256,'settings',settings);
    tmp=[tempname(fileparts(pointer)) '.json'];fid=fopen(tmp,'wt');assert(fid>=0);
    fprintf(fid,'%s',jsonencode(q,PrettyPrint=true));fclose(fid);[ok,msg]=movefile(tmp,pointer);assert(ok,'%s',msg);
    derived=fullfile(fileparts(manifestPath),'derived');mkdir(derived);
    save(fullfile(derived,'static_preflight.mat'),'preview','warmup','-v7');
end
out.manifest_path=manifestPath;
arm=struct('HardwareArmed',true,'operator_id',settings.operator_id,'session_id',settings.session_id, ...
    'arm_id',['arm_' char(java.util.UUID.randomUUID)], ...
    'confirmed_utc',char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));
out.report=pendulumlab.run_campaign(string(manifestPath),arm,@()isfile(options.StopFile));
out.state='held';if out.report.summary.completed==1,out.state='completed';end
fprintf('Static-map outcome: %s\n',out.state);
end
function drawPreview(p)
f=figure('Visible','off','Color','w','Position',[60 60 1100 700]);tiledlayout(f,2,1);
nexttile;plot(p.t,rad2deg(p.predicted_angle_rad),'LineWidth',1);grid on;ylabel('y [deg]');
legend(p.case_labels,'Location','best');title('Commissioning input: provisional simulations');
nexttile;stairs(p.t,p.u,'k:','LineWidth',1);hold on;plot(p.t,p.predicted_applied_u,'LineWidth',.8);grid on;xlabel('t [s]');ylabel('u [command units]');
exportgraphics(f,fullfile(tempdir,'pendulum_static_preview.png'),'Resolution',140);close(f);
end
function [y,applied,policy]=lagResponse(p,t,u,substeps,quadratic,policy)
if nargin<5,quadratic=true;end;if nargin<6,policy=[];end
y=zeros(size(t));v=0;angle=0;force=0;
if numel(p)==6,g1=p(3);g2=p(4);tau=p(5);c=p(6);
elseif quadratic,g1=0;g2=p(3);tau=p(4);c=0;
else,g1=p(3);g2=0;tau=p(4);c=0;end
applied=u;
for k=1:numel(t)-1
    if ~isempty(policy)
        policy=pendulumlab.identification_return(policy,angle,t(k),k);
        if policy.latched,applied(k)=0;end
    end
    h=(t(k+1)-t(k))/substeps;
    target=g1*applied(k)+g2*applied(k)^2/50;
    if tau>0,ee=exp(-h/(2*tau));else,ee=0;end
    for j=1:substeps
        if tau==0,force=target;end
        fh=target+(force-target)*ee;fe=target+(force-target)*ee^2;
        v1=v;a1=-p(1)*sin(angle)-p(2)*v1+force-c*tanh(v1/.03);
        v2=v+h*a1/2;a2=-p(1)*sin(angle+h*v1/2)-p(2)*v2+fh-c*tanh(v2/.03);
        v3=v+h*a2/2;a3=-p(1)*sin(angle+h*v2/2)-p(2)*v3+fh-c*tanh(v3/.03);
        v4=v+h*a3;a4=-p(1)*sin(angle+h*v3)-p(2)*v4+fe-c*tanh(v4/.03);
        angle=angle+h*(v1+2*v2+2*v3+v4)/6;v=v+h*(a1+2*a2+2*a3+a4)/6;force=fe;
    end
    y(k+1)=angle;
end
if ~isempty(policy)
    policy=pendulumlab.identification_return(policy,angle,t(end),numel(t));if policy.latched,applied(end)=0;end
end
end
function [w,design]=dynamicWaypoints(bias,amplitude,frequencies,seed)
% Eight periods of an 8-s multisine; one-period fade at either end.
stream=RandStream('mt19937ar','Seed',seed);tt=(0:.05:8-.05)';base=2*pi*tt*frequencies;
ta=(.05:.05:64)';activeBase=2*pi*ta*frequencies;
env=ones(size(ta));a=ta<8;env(a)=.5-.5*cos(pi*ta(a)/8);
a=ta>56;env(a)=.5-.5*cos(pi*(64-ta(a))/8);
best=Inf;feasible=0;draws=512;phaseSlewCap=28;
for k=1:draws
    ph=2*pi*rand(stream,1,numel(frequencies));wave=sum(sin(base+ph),2);pk=max(abs(wave));
    candidate=bias+amplitude*env.*sum(sin(activeBase+ph),2)/pk;
    slope=max(abs(diff([bias;candidate])))/.05;
    if slope<=phaseSlewCap
        feasible=feasible+1;
        if pk<best,best=pk;phases=ph;end
    end
end
assert(isfinite(best),'No phase realization meets the planned multisine slew constraint.');
wave=sum(sin(activeBase+phases),2)/best;
cmd=bias+amplitude*env.*wave;
w=[0 0;5 0;30 bias;40 bias;40+ta cmd;124 0;150 0];
maxSlope=max(abs(diff(w(:,2)))./diff(w(:,1)));
assert(maxSlope<30,'Multisine exceeds its planned derivative cap.');
design=struct('frequencies_hz',frequencies,'phase_seed',seed,'phases_rad',phases, ...
    'period_s',8,'active_interval_s',[40 104],'full_amplitude_interval_s',[48 96], ...
    'ramp_envelope_s',8,'requested_amplitude_command',amplitude,'bias_command',bias, ...
    'realized_command_range',[min(cmd) max(cmd)],'max_planned_slew_units_s',maxSlope, ...
    'phase_draws',draws,'feasible_phase_draws',feasible,'phase_slew_cap_units_s',phaseSlewCap, ...
    'note','Minimum unscaled peak among deterministic phase draws satisfying the slew constraint; actual waveform/termination are retained.');
end
