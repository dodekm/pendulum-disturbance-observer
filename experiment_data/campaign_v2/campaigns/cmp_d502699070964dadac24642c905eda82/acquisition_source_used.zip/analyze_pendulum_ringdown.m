function report=analyze_pendulum_ringdown()
%ANALYZE_PENDULUM_RINGDOWN Read-only physical-data QC and decay diagnostics.
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'experiment_framework'));
pointer=jsondecode(fileread(fullfile(root,'experiment_data','campaign_v2','identification_campaigns','revision_ringdown_01.json')));
folder=fileparts(pointer.manifest_path);m=jsondecode(fileread(pointer.manifest_path));
raw=fullfile(folder,'runs',[m.runs(1).run_id '.mat']);r=pendulumlab.load_runs(string(raw));
assert(strcmp(r.status.code,'completed')&&all(r.signals.read_valid)&&all(r.signals.write_succeeded));
q=load(fullfile(folder,m.runs(1).schedule_file),'schedule');zero=q.schedule.excitation.command_zero_start_s;
t=r.signals.t(:);y=r.signals.angle(:);u=r.signals.u_command(:);
tail=t>=100;baseline=mean(y(tail));floorStd=std(y(tail));
report=struct('status','commissioning_diagnostics_not_a_validated_model', ...
    'run_id',m.runs(1).run_id,'raw_file',raw,'raw_sha256',r.provenance.source_sha256, ...
    'samples',numel(t),'angle_range_deg',rad2deg([min(y) max(y)]),'command_range',[min(u) max(u)], ...
    'device_dt_range_s',[min(diff(r.signals.t_device)) max(diff(r.signals.t_device))], ...
    'max_host_read_cycle_s',max(diff(r.signals.read_start_host)), ...
    'stop_succeeded',r.status.stop_succeeded,'link_closed',r.status.link_closed, ...
    'checkpoint_committed_sample',r.metadata.checkpoint_committed_sample, ...
    'command_zero_start_s',zero,'final20s_mean_angle_deg',rad2deg(baseline), ...
    'final20s_std_angle_deg',rad2deg(floorStd), ...
    'interpretation','Command-zero decay with unknown zero-floor thrust; short damped-sinusoid fits are sensitivity diagnostics, not a powered-pendulum damping calibration.', ...
    'script_sha256',pendulumlab.file_hash([mfilename('fullpath') '.m']));
ix=t>=zero&t<zero+6;
report.first6s_zero_command_angle_range_deg=rad2deg([min(y(ix)) max(y(ix))]);
windows=[0 .25 .5 1];fits=cell(size(windows));curves=cell(size(windows));
op=optimoptions('lsqnonlin','Display','off','MaxIterations',120,'FiniteDifferenceType','central');
for j=1:numel(windows)
    ix=find(t>=zero+windows(j)&t<zero+6);tt=t(ix)-t(ix(1));yy=y(ix);best=Inf;
    for omega=[5 6 7 8 9]
        for lambda=[.2 1 3]
            q0=[omega/7;lambda;(yy(1)-baseline)/.02;0;baseline/.01];
            [v,cost,~,flag]=lsqnonlin(@(v)damped(v,tt)-yy,q0, ...
                [1e-8;0;-Inf;-Inf;-Inf],[pi/(.05*7);Inf;Inf;Inf;Inf],op);
            if flag>0&&cost<best,best=cost;selected=v;selectedFlag=flag;end
        end
    end
    assert(isfinite(best));omega=selected(1)*7;lambda=selected(2);
    fits{j}=struct('start_after_command_zero_s',windows(j),'duration_s',tt(end), ...
        'damped_frequency_hz',omega/(2*pi),'effective_beta_s_inv',2*lambda, ...
        'effective_small_angle_stiffness_s_inv2',omega^2+lambda^2, ...
        'initial_envelope_deg',rad2deg(hypot(selected(3)*.02,selected(4)*.02)), ...
        'rmse_deg',rad2deg(sqrt(best/numel(tt))),'fitted_baseline_deg',rad2deg(selected(5)*.01), ...
        'exitflag',selectedFlag,'parameters',selected');
    curves{j}=struct('t',t(ix),'yhat',damped(selected,tt));
end
report.decay_window_sensitivity=fits;
report.limitations={'One pilot is not repeatability data.', ...
    'Very small residual oscillations, unmeasured thrust at command zero, finite release and possible nonlinear friction limit damping interpretation.', ...
    'Effective stiffness and damping from a local sinusoid are not promoted global nonlinear plant parameters.', ...
    'Frequency search excludes aliases above Nyquist; no physical parameter upper bounds inferred.'};
folderOut=fullfile(folder,'derived');pathOut=fullfile(folderOut,'ringdown_checks.json');
assert(~isfile(pathOut),'Refusing to overwrite an analysis.');
save(fullfile(folderOut,'ringdown_checks.mat'),'report','curves','-v7');
fid=fopen(pathOut,'wt');assert(fid>=0);fprintf(fid,'%s',jsonencode(report,PrettyPrint=true));fclose(fid);
f=figure('Visible','off','Color','w','Position',[60 60 1050 700]);tiledlayout(f,2,1);
nexttile;plot(t,rad2deg(y),'k');hold on;cc=lines(numel(windows));
for j=1:numel(windows),plot(curves{j}.t,rad2deg(curves{j}.yhat),'Color',cc(j,:));end
xlim([zero zero+6]);ylabel('y [deg]');grid on;title('Command-zero decay: window-sensitivity diagnostics');
legend('Measured','Fit from zero','Fit after 0.25 s','Fit after 0.5 s','Fit after 1 s');
nexttile;plot(t,rad2deg(y),'k');xlim([20 40]);grid on;xlabel('t [s]');ylabel('y [deg]');xline(zero,':','Command zero');
savefig(f,fullfile(folder,'figures','ringdown_decay.fig'));print(f,fullfile(folder,'figures','ringdown_decay.eps'),'-depsc','-painters');
exportgraphics(f,fullfile(tempdir,'pendulum_ringdown_decay.png'),'Resolution',150);close(f);
assert(strcmp(pendulumlab.file_hash(raw),report.raw_sha256));
disp(jsonencode(report));
end
function y=damped(q,t)
y=q(5)*.01+exp(-q(2)*t).*(q(3)*.02*cos(q(1)*7*t)+q(4)*.02*sin(q(1)*7*t));
end
