function out=run_pendulum_ringdown(options)
%RUN_PENDULUM_RINGDOWN One commissioning recording; default is offline preview.
arguments
    options.Mode (1,1) string = "preview"
    options.HardwareArmed (1,1) logical = false
    options.MechanicalReady (1,1) logical = false
    options.AngleZeroConfirmed (1,1) logical = false
    options.ExcitationApproved (1,1) logical = false
    options.OperatingEnvelopeApproved (1,1) logical = false
    options.StopFile (1,1) string = ""
end
% SETTINGS: one slow rise, a short plateau, controlled release, long ringdown.
settings.campaign_label='revision_ringdown_01';
settings.operator_id='Martin Dodek';settings.session_id='revision_id_session_01';
settings.command=25;settings.baseline_s=5;settings.rise_s=15;
settings.hold_s=10;settings.release_s=1.25;settings.duration_s=120;
settings.planned_slew=20;settings.runtime_slew=40;settings.recovery_s=20;
settings.max_abs_angle_deg=180;settings.COM_port=4;
root=fileparts(mfilename('fullpath'));addpath(root);addpath(fullfile(root,'experiment_framework'));
assert(any(options.Mode==["preview","hardware"]),'Use preview or hardware.');
protected=pendulumlab.verify_protected();assert(protected.passed,'Protected project files changed.');
cfg=pendulumlab.default_config('identification');
cfg.experiment_launcher_source_sha256=pendulumlab.file_hash([mfilename('fullpath') '.m']);
cfg.experiment_id='identification_ringdown';cfg.mode='mock';
cfg.protocol.bias_command=settings.command;cfg.protocol.amplitude_command=0;
cfg.protocol.baseline_s=settings.baseline_s;cfg.protocol.ramp_s=settings.rise_s;
cfg.protocol.dwell_s=settings.hold_s;cfg.protocol.ramp_down_s=settings.release_s;
cfg.protocol.duration_s=settings.duration_s;cfg.protocol.seed=2117;
cfg.protocol.command_slew_units_s=settings.planned_slew;
cfg.safety.max_abs_angle_rad=deg2rad(settings.max_abs_angle_deg);
cfg.safety.max_slew_units_s=settings.runtime_slew;
cfg.safety.max_duration_s=180;cfg.hardware.COM_port=settings.COM_port;
cfg.campaign.plan='identification';cfg.campaign.intertrial_recovery_s=settings.recovery_s;
cfg.campaign.identification_profiles=struct('experiment_id',cfg.experiment_id, ...
    'bias_command',settings.command,'amplitude_command',0,'ramp_s',settings.rise_s, ...
    'dwell_s',settings.hold_s,'command_slew_units_s',settings.planned_slew);
cfg.experiment_notes='Commissioning: slow motor-induced displacement followed by command-zero ringdown; no claim of verified zero thrust.';
previewCfg=cfg;stages=pendulumlab.identification_stages(cfg);
previewCfg.protocol=stages(1).protocol;previewCfg.rng_seed=cfg.rng_seed+1;
schedule=pendulumlab.make_schedule(previewCfg);
% Use original, recording-specific, and quadratic-lag fits as planning cases.
prior=fullfile(root,'experiment_data','campaign_v2','campaigns', ...
    'cmp_ab0b8a9eed03446e8dbe91d3c9c8d7c0','derived','identification_20261106_141039','identification.mat');
z=load(prior,'report');theta=[z.report.settings.historical_theta;z.report.individual{1}.theta;z.report.individual{2}.theta];
u=double(single(schedule.command));pred=zeros(numel(u),4);
for k=1:3,pred(:,k)=pendulumlab.simulate_output(theta(k,:),schedule.t,u,[0;0],4);end
diagnostic=fullfile(fileparts(fileparts(prior)),'mismatch_diagnostics_20261106_142624','diagnostics.mat');
z=load(diagnostic,'report');p=z.report.results{5}.pooled.parameters;
pred(:,4)=lagResponse(p,schedule.t,u,4);
fine=lagResponse(p,schedule.t,u,8);
preview=struct('settings',settings,'theta_cases',theta,'quadratic_lag_parameters',p, ...
    't',schedule.t,'u',u,'predicted_angle_rad',pred, ...
    'angle_ranges_deg',rad2deg([min(pred,[],1);max(pred,[],1)]), ...
    'lag_substep_doubling_max_deg',rad2deg(max(abs(fine-pred(:,4)))), ...
    'model_note','Provisional models screen the low-command pilot; no physical safety or validation claim.', ...
    'diagnostic_source_sha256',pendulumlab.file_hash(diagnostic), ...
    'launcher_sha256',pendulumlab.file_hash([mfilename('fullpath') '.m']));
assert(max(abs(preview.angle_ranges_deg(:)))<90,'Planning cases exceed the agreed design target.');
assert(max(abs(diff(u)))/cfg.Ts<settings.runtime_slew,'Waveform exceeds runtime slew.');
out=struct('state','preview','preview',preview,'manifest_path','','report',struct());
fprintf('Ringdown plan: command 0..%g; zero from %.2f s; total %.1f s.\n',settings.command,schedule.excitation.command_zero_start_s,settings.duration_s);
disp(preview.angle_ranges_deg);
if options.Mode=="preview"
    f=figure('Visible','off','Color','w','Position',[60 60 1050 680]);tiledlayout(f,2,1);
    nexttile;plot(schedule.t,rad2deg(pred),'LineWidth',1);grid on;ylabel('y [deg]');
    legend('Historical model','Run 1 fit','Run 2 fit','Quadratic + lag','Location','best');
    title('Provisional simulations of the commissioning ringdown');
    nexttile;stairs(schedule.t,u,'LineWidth',1);grid on;xlabel('t [s]');ylabel('u [command units]');
    exportgraphics(f,fullfile(tempdir,'pendulum_ringdown_preview.png'),'Resolution',140);close(f);return
end
assert(options.HardwareArmed,'A fresh explicit runtime arm is required.');
assert(options.MechanicalReady&&options.AngleZeroConfirmed&&options.ExcitationApproved&&options.OperatingEnvelopeApproved, ...
    'Explicit mechanical readiness, angle-zero, excitation and operating-envelope confirmations are required.');
assert(strlength(options.StopFile)>0&&~isfile(options.StopFile),'Provide a fresh, nonexistent stop-flag path.');
cfg.mode='hardware';cfg.output_dir=fullfile(root,'experiment_data','campaign_v2');cfg.session_id='';
cfg.hardware.enabled=true;cfg.hardware.operator_armed=true;
cfg.hardware.mechanical_ready=options.MechanicalReady;cfg.hardware.angle_zero_confirmed=options.AngleZeroConfirmed;
cfg.protocol.operator_excitation_approved=options.ExcitationApproved;
cfg.protocol.operating_envelope_approved=options.OperatingEnvelopeApproved;
ready=pendulumlab.validate_config(cfg);assert(ready.hardware_allowed,'%s',strjoin(ready.issues,'; '));
pointer=fullfile(cfg.output_dir,'identification_campaigns',[settings.campaign_label '.json']);
if isfile(pointer)
    q=jsondecode(fileread(pointer));
    assert(strcmp(q.config_sha256,pendulumlab.json_value_sha256(cfg)),'Settings changed under the existing campaign label.');
    assert(strcmp(q.manifest_sha256,pendulumlab.file_hash(q.manifest_path)),'Manifest differs from frozen pointer.');
    manifestPath=q.manifest_path;
else
    manifest=pendulumlab.prepare_campaign(cfg,'identification');manifestPath=manifest.manifest_path;
    frozen=load(fullfile(manifest.campaign_folder,manifest.runs(1).schedule_file),'schedule');
    assert(strcmp(pendulumlab.schedule_identity_sha256(schedule), ...
        pendulumlab.schedule_identity_sha256(frozen.schedule)),'Frozen input differs from reviewed preview.');
    q=struct('schema_version','pendulumlab.ringdown_launcher/1','config_sha256',pendulumlab.json_value_sha256(cfg), ...
        'manifest_path',manifestPath,'manifest_sha256',manifest.manifest_sha256,'settings',settings);
    fid=fopen(pointer,'wt');assert(fid>=0);fprintf(fid,'%s',jsonencode(q,PrettyPrint=true));fclose(fid);
    derived=fullfile(fileparts(manifestPath),'derived');mkdir(derived);
    save(fullfile(derived,'ringdown_preflight.mat'),'preview','-v7');
end
out.manifest_path=manifestPath;
arm=struct('HardwareArmed',true,'operator_id',settings.operator_id,'session_id',settings.session_id, ...
    'arm_id',['arm_' char(java.util.UUID.randomUUID)], ...
    'confirmed_utc',char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));
out.report=pendulumlab.run_campaign(string(manifestPath),arm,@()isfile(options.StopFile));
out.state='held';if out.report.summary.completed==1,out.state='completed';end
fprintf('Ringdown outcome: %s\n',out.state);
if out.state=="completed"
    folder=fileparts(manifestPath);row=out.report.runs(1);
    raw=fullfile(folder,'runs',[row.run_id '.mat']);r=pendulumlab.load_runs(string(raw));
    f=figure('Visible','off','Color','w','Position',[60 60 1050 680]);tiledlayout(f,2,1);
    nexttile;plot(r.signals.t,rad2deg(r.signals.angle),'k','LineWidth',1);grid on;
    ylabel('y [deg]');title('Measured commissioning response');xline(schedule.excitation.command_zero_start_s,':','Command zero');
    nexttile;stairs(r.signals.t,r.signals.u_command,'LineWidth',1);grid on;xlabel('t [s]');ylabel('u [command units]');
    figs=fullfile(folder,'figures');if ~isfolder(figs),mkdir(figs);end
    savefig(f,fullfile(figs,[row.run_id '.fig']));print(f,fullfile(figs,[row.run_id '.eps']),'-depsc','-painters');
    exportgraphics(f,fullfile(tempdir,'pendulum_ringdown_measured.png'),'Resolution',140);close(f);
    out.raw_file=raw;out.angle_range_deg=rad2deg([min(r.signals.angle) max(r.signals.angle)]);
    fprintf('Measured angle range [%g, %g] deg; raw data %s\n',out.angle_range_deg,raw);
end
end

function y=lagResponse(p,t,u,substeps)
y=zeros(size(t));v=0;angle=0;force=0;
for k=1:numel(t)-1
    h=(t(k+1)-t(k))/substeps;target=p(3)*u(k)^2/50;
    ee=exp(-h/(2*p(4)));
    for j=1:substeps
        fh=target+(force-target)*ee;fe=target+(force-target)*ee^2;
        v1=v;a1=-p(1)*sin(angle)-p(2)*v1+force;
        v2=v+h*a1/2;a2=-p(1)*sin(angle+h*v1/2)-p(2)*v2+fh;
        v3=v+h*a2/2;a3=-p(1)*sin(angle+h*v2/2)-p(2)*v3+fh;
        v4=v+h*a3;a4=-p(1)*sin(angle+h*v3)-p(2)*v4+fe;
        angle=angle+h*(v1+2*v2+2*v3+v4)/6;v=v+h*(a1+2*a2+2*a3+a4)/6;force=fe;
    end
    y(k+1)=angle;
end
end
