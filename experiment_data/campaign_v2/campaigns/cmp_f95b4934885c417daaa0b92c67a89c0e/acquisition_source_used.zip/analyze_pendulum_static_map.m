function report=analyze_pendulum_static_map(options)
%ANALYZE_PENDULUM_STATIC_MAP Fixed-window QC of the completed static-map pilot.
% No UART access and no model-registry or raw-data changes.
arguments
    options.CampaignLabel (1,1) string = "revision_static_01"
end
assert(~isempty(regexp(char(options.CampaignLabel),'^[A-Za-z0-9_-]+$','once')),'Invalid campaign label.');
root=fileparts(mfilename('fullpath'));addpath(fullfile(root,'experiment_framework'));
q=jsondecode(fileread(fullfile(root,'experiment_data','campaign_v2','identification_campaigns',[char(options.CampaignLabel) '.json'])));
folder=fileparts(q.manifest_path);m=jsondecode(fileread(q.manifest_path));
raw=fullfile(folder,'runs',[m.runs(1).run_id '.mat']);r=pendulumlab.load_runs(string(raw));
assert(strcmp(r.status.code,'completed')&&all(r.signals.read_valid)&&all(r.signals.write_succeeded));
assert(strcmp(r.metadata.run_id,m.runs(1).run_id)&&strcmp(r.metadata.hardware_id,m.hardware_id));
z=load(fullfile(folder,m.runs(1).schedule_file),'cfgRun','schedule');
assert(strcmp(z.schedule.name,'identification_static_map'));
window=z.cfgRun.analysis.static_tail_window_s;ranges=z.schedule.excitation.plateau_ranges_s;
levels=z.schedule.excitation.plateau_commands;t=r.signals.t(:);y=r.signals.angle(:);u=r.signals.u_command(:);
report=struct('status','descriptive_static_pilot_not_validated_or_promoted', ...
    'run_id',m.runs(1).run_id,'raw_file',raw,'raw_sha256',r.provenance.source_sha256, ...
    'samples',numel(t),'angle_range_deg',rad2deg([min(y) max(y)]),'command_range',[min(u) max(u)], ...
    'device_dt_range_s',[min(diff(r.signals.t_device)) max(diff(r.signals.t_device))], ...
    'max_host_read_cycle_s',max(diff(r.signals.read_start_host)), ...
    'stop_succeeded',r.status.stop_succeeded,'link_closed',r.status.link_closed, ...
    'checkpoint_committed_sample',r.metadata.checkpoint_committed_sample, ...
    'tail_window_s',window,'scoring_rule','Last 10 s of each planned 20-s plateau, frozen before acquisition; no measured settling-point selection.', ...
    'script_sha256',pendulumlab.file_hash([mfilename('fullpath') '.m']));
plateaus=struct([]);
for j=1:numel(levels)
    bounds=[ranges(j,2)-window ranges(j,2)];ix=t>=bounds(1)&t<bounds(2);
    assert(all(u(ix)==levels(j)),'Tail contains a command transition.');
    tt=t(ix);yy=rad2deg(y(ix));fit=[tt-mean(tt),ones(size(tt))]\yy;
    previous=0;if j>1,previous=levels(j-1);end
    direction='ascending';if levels(j)<previous,direction='descending';end
    plateaus(j).command=levels(j);plateaus(j).direction=direction;
    plateaus(j).servo_argument=fix(double(single(single(levels(j))*single(170))/single(100)+single(10)));
    plateaus(j).planned_interval_s=ranges(j,:);plateaus(j).scored_interval_s=bounds;
    plateaus(j).samples=sum(ix);plateaus(j).mean_angle_deg=mean(yy);
    plateaus(j).std_angle_deg=std(yy);plateaus(j).peak_to_peak_deg=max(yy)-min(yy);
    plateaus(j).angle_slope_deg_s=fit(1);plateaus(j).mean_sin_angle=mean(sin(y(ix)));
    a=tt<mean(bounds);plateaus(j).second_half_minus_first_half_mean_deg=mean(yy(~a))-mean(yy(a));
end
report.plateaus=plateaus;
initial=t<z.cfgRun.protocol.baseline_s;last=t>=t(end)+z.cfgRun.Ts-window;
report.zero_baselines=struct('initial_mean_deg',rad2deg(mean(y(initial))), ...
    'final_mean_deg',rad2deg(mean(y(last))),'final_std_deg',rad2deg(std(y(last))), ...
    'final_minus_initial_mean_deg',rad2deg(mean(y(last))-mean(y(initial))));
comparison=struct([]);repeated=intersect([plateaus(strcmp({plateaus.direction},'ascending')).command], ...
    [plateaus(strcmp({plateaus.direction},'descending')).command]);
for j=1:numel(repeated)
    level=repeated(j);
    a=find([plateaus.command]==level&strcmp({plateaus.direction},'ascending'));
    b=find([plateaus.command]==level&strcmp({plateaus.direction},'descending'));
    assert(numel(a)==1&&numel(b)==1);
    comparison(j).command=level;comparison(j).ascending_mean_deg=plateaus(a).mean_angle_deg;
    comparison(j).descending_mean_deg=plateaus(b).mean_angle_deg;
    comparison(j).descending_minus_ascending_deg=plateaus(b).mean_angle_deg-plateaus(a).mean_angle_deg;
end
report.direction_comparison=comparison;
% Normalized descriptive curve fits; alpha and physical thrust are not inferred.
x=levels(:)/50;baselineSin=mean(sin(y(last)));target=[plateaus.mean_sin_angle]'-baselineSin;
curves={x,x.^2,[x x.^2]};names={'linear','quadratic','nonnegative_linear_plus_quadratic'};curveFits=cell(1,3);
for j=1:3
    c=lsqnonneg(curves{j},target);ys=baselineSin+curves{j}*c;
    assert(all(abs(ys)<1),'A descriptive fit predicts an invalid equilibrium sine at an observed command.');
    curveFits{j}=struct('name',names{j},'coefficients',c','target_rmse',sqrt(mean((curves{j}*c-target).^2)), ...
        'angle_equivalent_rmse_deg',sqrt(mean((asind(ys)-[plateaus.mean_angle_deg]').^2)));
end
report.curve_fits=struct('definition','Mean sin(y) minus terminal command-zero mean sin(y), versus x=u/50.', ...
    'interpretation','Descriptive fits of five late-window means at three unique positive commands; conditional equilibrium interpretation, not a thrust curve or independent validation.', ...
    'fits',{curveFits});
report.limitations={'One ascending/descending sweep is not physical repeatability data.', ...
    'Late-window mean and oscillation spread are reported separately; no automatic declaration of exact static equilibrium.', ...
    'Direction is confounded with elapsed time; paired differences do not establish hysteresis uniquely.', ...
    'Thrust, RPM and applied torque were not measured; command-zero thrust is unverified.', ...
    'Within-window SD describes motion and measurement spread, not a confidence interval for the mean.'};
derived=fullfile(folder,'derived');targetFile=fullfile(derived,'static_checks.json');
assert(~isfile(targetFile),'Refusing to overwrite the existing analysis.');
save(fullfile(derived,'static_checks.mat'),'report','-v7');
fid=fopen(targetFile,'wt');assert(fid>=0);fprintf(fid,'%s',jsonencode(report,PrettyPrint=true));fclose(fid);
figs=fullfile(folder,'figures');if ~isfolder(figs),mkdir(figs);end
f=figure('Visible','off','Color','w','Position',[60 60 1100 740]);tiledlayout(f,2,1);
nexttile;plot(t,rad2deg(y),'k','LineWidth',1);grid on;ylabel('y [deg]');title('Measured ascending/descending command-plateau response');
nexttile;stairs(t,u,'Color',[.1 .35 .7],'LineWidth',1);grid on;xlabel('t [s]');ylabel('u [command units]');
savefig(f,fullfile(figs,'static_map_response.fig'));print(f,fullfile(figs,'static_map_response.eps'),'-depsc','-painters');
exportgraphics(f,fullfile(tempdir,'pendulum_static_measured.png'),'Resolution',150);close(f);
g=figure('Visible','off','Color','w','Position',[60 60 850 560]);hold on;
a=strcmp({plateaus.direction},'ascending');b=~a;
errorbar([plateaus(a).command],[plateaus(a).mean_angle_deg],[plateaus(a).std_angle_deg],'-o','LineWidth',1.2);
errorbar([plateaus(b).command],[plateaus(b).mean_angle_deg],[plateaus(b).std_angle_deg],'-s','LineWidth',1.2);
grid on;xlabel('u [command units]');ylabel('Late-window mean y [deg]');
legend('Ascending: mean +/- SD','Descending: mean +/- SD','Location','northwest');
title('Pilot command-to-angle observations: spread is not a confidence interval');
savefig(g,fullfile(figs,'static_map_means.fig'));print(g,fullfile(figs,'static_map_means.eps'),'-depsc','-painters');
exportgraphics(g,fullfile(tempdir,'pendulum_static_means.png'),'Resolution',150);close(g);
assert(strcmp(pendulumlab.file_hash(raw),report.raw_sha256));
disp(jsonencode(report));
end
