function out=run_pendulum_static_map(options)
%RUN_PENDULUM_STATIC_MAP One low-command ascending/descending recording.
% Default preview opens no UART. Settings are at the beginning of this file.
arguments
    options.Mode (1,1) string = "preview"
    options.Profile (1,1) string = "low"
    options.HardwareArmed (1,1) logical = false
    options.MechanicalReady (1,1) logical = false
    options.AngleZeroConfirmed (1,1) logical = false
    options.ExcitationApproved (1,1) logical = false
    options.OperatingEnvelopeApproved (1,1) logical = false
    options.StopFile (1,1) string = ""
end
settings.campaign_label='revision_static_01';
settings.preceding_campaign_label='revision_ringdown_01';
settings.operator_id='Martin Dodek';settings.session_id='revision_id_session_01';
% [time in seconds, command]. Flat sections are 20-s observation plateaus.
settings.waypoints=[0 0;5 0;15 20;35 20;40 25;60 25;65 30;85 30; ...
    90 25;110 25;115 20;135 20;145 0;165 0];
assert(any(options.Profile==["low","extended"]),'Use low or extended profile.');
if options.Profile=="extended"
    settings.campaign_label='revision_static_02';
    settings.preceding_campaign_label='revision_static_01';
    settings.waypoints=[0 0;5 0;20 30;40 30;43.75 37.5;63.75 37.5; ...
        67.5 45;87.5 45;91.25 37.5;111.25 37.5;115 30;135 30;150 0;170 0];
end
settings.planned_slew=2;settings.runtime_slew=40;settings.recovery_s=20;
settings.max_abs_angle_deg=180;settings.COM_port=4;
settings.tail_window_s=10; % frozen descriptive scoring window, not a settling claim
root=fileparts(mfilename('fullpath'));addpath(root);addpath(fullfile(root,'experiment_framework'));
assert(any(options.Mode==["preview","hardware"]),'Use preview or hardware.');
protected=pendulumlab.verify_protected();assert(protected.passed,'Protected project files changed.');
cfg=pendulumlab.default_config('identification');cfg.mode='mock';
cfg.experiment_launcher_source_sha256=pendulumlab.file_hash([mfilename('fullpath') '.m']);
cfg.experiment_id='identification_static_map';cfg.protocol.static_waypoints=settings.waypoints;
cfg.protocol.duration_s=settings.waypoints(end,1);cfg.protocol.baseline_s=settings.waypoints(2,1);
cfg.protocol.bias_command=max(settings.waypoints(:,2));cfg.protocol.amplitude_command=0;
cfg.protocol.ramp_s=settings.waypoints(3,1)-settings.waypoints(2,1);cfg.protocol.dwell_s=20;cfg.protocol.seed=3117;
cfg.protocol.command_slew_units_s=settings.planned_slew;
cfg.safety.max_abs_angle_rad=deg2rad(settings.max_abs_angle_deg);
cfg.safety.max_slew_units_s=settings.runtime_slew;cfg.safety.max_duration_s=180;
cfg.hardware.COM_port=settings.COM_port;cfg.analysis.static_tail_window_s=settings.tail_window_s;
cfg.campaign.plan='identification';cfg.campaign.intertrial_recovery_s=settings.recovery_s;
cfg.campaign.identification_profiles=struct('experiment_id',cfg.experiment_id, ...
    'bias_command',cfg.protocol.bias_command,'amplitude_command',0,'ramp_s',cfg.protocol.ramp_s, ...
    'dwell_s',20,'command_slew_units_s',settings.planned_slew);
cfg.experiment_notes=['Static-map commissioning (' char(options.Profile) '): explicit waypoint plateaus, slow ramps and final zero. Mean angle and stationarity are assessed separately; actual thrust is unmeasured.'];
st=pendulumlab.identification_stages(cfg);previewCfg=cfg;
previewCfg.protocol=st.protocol;previewCfg.rng_seed=cfg.rng_seed+1;
schedule=pendulumlab.make_schedule(previewCfg);u=double(single(schedule.command));
old=fullfile(root,'experiment_data','campaign_v2','campaigns', ...
    'cmp_ab0b8a9eed03446e8dbe91d3c9c8d7c0','derived');
z=load(fullfile(old,'identification_20261106_141039','identification.mat'),'report');
theta=[z.report.settings.historical_theta;z.report.individual{1}.theta;z.report.individual{2}.theta];
pred=zeros(numel(u),4);
for k=1:3,pred(:,k)=pendulumlab.simulate_output(theta(k,:),schedule.t,u,[0;0],4);end
diagnostic=fullfile(old,'mismatch_diagnostics_20261106_142624','diagnostics.mat');
z=load(diagnostic,'report');p=z.report.results{5}.pooled.parameters;
% Static nonlinearity and exact held-input first-order forcing are used only
% to screen the proposed input, not to replace the controller's nominal model.
pred(:,4)=lagResponse(p,schedule.t,u,4);
preview=struct('settings',settings,'theta_cases',theta,'quadratic_lag_parameters',p, ...
    't',schedule.t,'u',u,'predicted_angle_rad',pred, ...
    'angle_ranges_deg',rad2deg([min(pred,[],1);max(pred,[],1)]), ...
    'max_payload_slew_units_s',max(abs(diff(u)))/cfg.Ts, ...
    'lag_substep_doubling_max_deg',rad2deg(max(abs(pred(:,4)-lagResponse(p,schedule.t,u,8)))), ...
    'model_note','Provisional model cases, not a probability envelope or physical safety guarantee.', ...
    'diagnostic_source_sha256',pendulumlab.file_hash(diagnostic), ...
    'launcher_sha256',cfg.experiment_launcher_source_sha256);
assert(max(abs(preview.angle_ranges_deg(:)))<90,'A planning case exceeds the design target.');
assert(preview.max_payload_slew_units_s<settings.runtime_slew,'Payload slew exceeds runtime interlock.');
assert(cfg.protocol.duration_s+cfg.safety.rest_samples*cfg.Ts+5<cfg.safety.max_duration_s, ...
    'Leave timing headroom for connection, rest and acquisition.');
out=struct('state','preview','preview',preview,'manifest_path','','report',struct());
fprintf('Static plan: %s; 20-s plateaus; %.1f s; zero from %.1f s.\n', ...
    strjoin(cellstr(compose('%g',schedule.excitation.plateau_commands)),' -> '), ...
    cfg.protocol.duration_s,schedule.excitation.command_zero_start_s);disp(preview.angle_ranges_deg);
if options.Mode=="preview"
    drawPreview(preview);return
end
assert(options.HardwareArmed&&options.MechanicalReady&&options.AngleZeroConfirmed&& ...
    options.ExcitationApproved&&options.OperatingEnvelopeApproved,'Explicit current-session confirmations are required.');
assert(strlength(options.StopFile)>0&&~isfile(options.StopFile),'Provide a fresh nonexistent stop-flag path.');
% Enforce recovery from the previous physical recording across campaign labels.
last=jsondecode(fileread(fullfile(root,'experiment_data','campaign_v2','identification_campaigns',[settings.preceding_campaign_label '.json'])));
lastStatus=jsondecode(fileread(fullfile(fileparts(last.manifest_path),'campaign_status.json')));
[ok,reason]=pendulumlab.recovery_gate(lastStatus.runs,settings.recovery_s);assert(ok,'%s',reason);
cfg.mode='hardware';cfg.output_dir=fullfile(root,'experiment_data','campaign_v2');cfg.session_id='';
cfg.hardware.enabled=true;cfg.hardware.operator_armed=options.HardwareArmed;
cfg.hardware.mechanical_ready=options.MechanicalReady;cfg.hardware.angle_zero_confirmed=options.AngleZeroConfirmed;
cfg.protocol.operator_excitation_approved=options.ExcitationApproved;
cfg.protocol.operating_envelope_approved=options.OperatingEnvelopeApproved;
ready=pendulumlab.validate_config(cfg);assert(ready.hardware_allowed,'%s',strjoin(ready.issues,'; '));
pointer=fullfile(cfg.output_dir,'identification_campaigns',[settings.campaign_label '.json']);
if isfile(pointer)
    q=jsondecode(fileread(pointer));
    assert(strcmp(q.config_sha256,pendulumlab.json_value_sha256(cfg)),'Settings changed under this label.');
    assert(strcmp(q.manifest_sha256,pendulumlab.file_hash(q.manifest_path)),'Frozen manifest changed.');
    manifestPath=q.manifest_path;
else
    manifest=pendulumlab.prepare_campaign(cfg,'identification');manifestPath=manifest.manifest_path;
    frozen=load(fullfile(manifest.campaign_folder,manifest.runs(1).schedule_file),'schedule');
    assert(strcmp(pendulumlab.schedule_identity_sha256(schedule),pendulumlab.schedule_identity_sha256(frozen.schedule)), ...
        'Frozen waveform differs from the preview.');
    q=struct('schema_version','pendulumlab.static_launcher/1','config_sha256',pendulumlab.json_value_sha256(cfg), ...
        'manifest_path',manifestPath,'manifest_sha256',manifest.manifest_sha256,'settings',settings);
    tmp=[tempname(fileparts(pointer)) '.json'];fid=fopen(tmp,'wt');assert(fid>=0);
    fprintf(fid,'%s',jsonencode(q,PrettyPrint=true));fclose(fid);[ok,msg]=movefile(tmp,pointer);assert(ok,'%s',msg);
    derived=fullfile(fileparts(manifestPath),'derived');mkdir(derived);
    save(fullfile(derived,'static_preflight.mat'),'preview','-v7');
end
out.manifest_path=manifestPath;
arm=struct('HardwareArmed',true,'operator_id',settings.operator_id,'session_id',settings.session_id, ...
    'arm_id',['arm_' char(java.util.UUID.randomUUID)], ...
    'confirmed_utc',char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));
out.report=pendulumlab.run_campaign(string(manifestPath),arm,@()isfile(options.StopFile));
out.state='held';if out.report.summary.completed==1,out.state='completed';end
fprintf('Static-map outcome: %s\n',out.state);
end
function drawPreview(p)
f=figure('Visible','off','Color','w','Position',[60 60 1100 700]);tiledlayout(f,2,1);
nexttile;plot(p.t,rad2deg(p.predicted_angle_rad),'LineWidth',1);grid on;ylabel('y [deg]');
legend('Historical','Run 1 fit','Run 2 fit','Quadratic + lag','Location','best');title('Static-map pilot: provisional simulations');
nexttile;stairs(p.t,p.u,'LineWidth',1);grid on;xlabel('t [s]');ylabel('u [command units]');
exportgraphics(f,fullfile(tempdir,'pendulum_static_preview.png'),'Resolution',140);close(f);
end
function y=lagResponse(p,t,u,substeps)
y=zeros(size(t));v=0;angle=0;force=0;
for k=1:numel(t)-1
    h=(t(k+1)-t(k))/substeps;target=p(3)*u(k)^2/50;ee=exp(-h/(2*p(4)));
    for j=1:substeps
        fh=target+(force-target)*ee;fe=target+(force-target)*ee^2;
        v1=v;a1=-p(1)*sin(angle)-p(2)*v1+force;
        v2=v+h*a1/2;a2=-p(1)*sin(angle+h*v1/2)-p(2)*v2+fh;
        v3=v+h*a2/2;a3=-p(1)*sin(angle+h*v2/2)-p(2)*v3+fh;
        v4=v+h*a3;a4=-p(1)*sin(angle+h*v3)-p(2)*v4+fe;
        angle=angle+h*(v1+2*v2+2*v3+v4)/6;v=v+h*(a1+2*a2+2*a3+a4)/6;force=fe;
    end
    y(k+1)=angle;
end
end
